import streamlit as st
import pickle
import re
import string

# Simple stopwords list (small, demo-friendly)
STOPWORDS = set("""a about above after again against all am an and any are arent as at be because been
before being below between both but by cant cannot could couldnt did didnt do does doesnt doing dont down during
each few for from further had hadnt has hasnt have havent having he hed hes her here heres hers herself him
himself his how hows i id i'll i'm ive if in into is isnt it its itself let's me more most mustnt my myself
no nor not of off on once only or other ought our ours ourselves out over own same shant she she'd she'll she's
should shouldnt so some such than that thats the their theirs them themselves then there theres these they theyd
they'll they're they've this those through to too under until up very was wasnt we we'd we'll we're we've were
weren't what whats when when's where where's which while who who's whom why why's with wont would wouldnt you
you'd you'll you're youve your yours yourself yourselves""".split())

# Load vectorizer and model
with open("vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

st.set_page_config(page_title="Email/SMS Spam Classifier", page_icon="📧", layout="centered")
st.title("📧 Email/SMS Spam Classifier")
st.markdown("Paste an email or SMS message below and click **Predict**.")

def preprocess(text: str) -> str:
    # lowercase
    text = text.lower()
    # remove urls and emails
    text = re.sub(r'http\S+|www\.\S+', ' ', text)
    text = re.sub(r'\S+@\S+', ' ', text)
    # remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # tokenize on whitespace
    tokens = text.split()
    # remove stopwords and short tokens
    tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 1 and not t.isdigit()]
    return " ".join(tokens)

input_text = st.text_area("Enter the message to classify:", height=200)

if st.button("Predict"):
    if not input_text.strip():
        st.warning("Please enter a message to classify.")
    else:
        cleaned = preprocess(input_text)
        vect = vectorizer.transform([cleaned])
        pred = model.predict(vect)[0]
        if pred == 1:
            st.error("🚫 Spam")
        else:
            st.success("✅ Not Spam")

st.markdown("---")

